# version.py
__version__ = "1.0.50"