# __init__.py
from .version import __version__
from .windbg_copilot import start