# setup.py
from setuptools import setup

if __name__ == "__main__":
  setup(packages = ['windbg_copilot'])